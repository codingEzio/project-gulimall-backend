package com.elliot.gulimall.gulimallorder.dao;

import com.elliot.gulimall.gulimallorder.entity.OrderReturnReasonEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 退货原因
 * 
 * @author Elliot
 * @email example@example.com
 * @date 2022-10-04 14:27:59
 */
@Mapper
public interface OrderReturnReasonDao extends BaseMapper<OrderReturnReasonEntity> {
	
}
