package com.elliot.gulimall.gulimallproduct.dao;

import com.elliot.gulimall.gulimallproduct.entity.AttrEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 商品属性
 * 
 * @author Elliot
 * @email example@example.com
 * @date 2022-10-04 14:28:52
 */
@Mapper
public interface AttrDao extends BaseMapper<AttrEntity> {
	
}
