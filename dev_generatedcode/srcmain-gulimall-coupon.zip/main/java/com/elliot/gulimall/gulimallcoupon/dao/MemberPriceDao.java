package com.elliot.gulimall.gulimallcoupon.dao;

import com.elliot.gulimall.gulimallcoupon.entity.MemberPriceEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 商品会员价格
 * 
 * @author Elliot
 * @email example@example.com
 * @date 2022-10-04 14:22:59
 */
@Mapper
public interface MemberPriceDao extends BaseMapper<MemberPriceEntity> {
	
}
